sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/format/DateFormat"
], function (Controller, MessageBox, JSONModel, DateFormat) {
    "use strict";

    return Controller.extend("com.sap.mm.sesapproval.controller.Object", {
        onInit: function () {
            this.oRouter = this.getOwnerComponent().getRouter();
            this.oRouter.getRoute("object").attachPatternMatched(this._onObjectMatched, this);
            
            // Initialize rejection dialog model
            this.getView().setModel(new JSONModel({
                rejectionText: ""
            }), "rejectionModel");
        },

        _onObjectMatched: function (oEvent) {
            var sSESNumber = oEvent.getParameter("arguments").SESNumber,
                sPackageNumber = oEvent.getParameter("arguments").PackageNumber;

            this.sSESNumber = sSESNumber;
            this.sPackageNumber = sPackageNumber;

            // Bind the object page to the selected workitem
            var sPath = "/Workitems(SESNumber='" + sSESNumber + "',PackageNumber='" + sPackageNumber + "')";
            this.getView().bindElement({
                path: sPath,
                parameters: {
                    expand: "SESHeaderDetails"
                }
            });
        },

        onApprove: function () {
            var oView = this.getView(),
                oModel = oView.getModel();

            MessageBox.confirm("Do you want to approve this Service Entry Sheet?", {
                title: "Confirm Approval",
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        this._executeApproval(oModel);
                    }
                }.bind(this)
            });
        },

        _executeApproval: function (oModel) {
            var sSESNumber = this.sSESNumber,
                sReleaseCode = "";

            // Get the next release code from the binding context
            var oContext = this.getView().getBindingContext();
            if (oContext) {
                var oData = oContext.getObject();
                sReleaseCode = oData.NextReleaseCode || "";
            }

            if (!sReleaseCode) {
                MessageBox.error("No release code available for approval.");
                return;
            }

            oModel.callFunction("/approveServiceEntrySheet", {
                method: "POST",
                urlParameters: {
                    SESNumber: sSESNumber,
                    ReleaseCode: sReleaseCode
                },
                success: function (oData, oResponse) {
                    if (oData && oData.ActionSuccessful) {
                        MessageBox.success("Service Entry Sheet approved successfully!", {
                            onClose: function () {
                                this.oRouter.navTo("worklist");
                            }.bind(this)
                        });
                    } else {
                        MessageBox.error(oData.Message || "Approval failed.");
                    }
                }.bind(this),
                error: function (oError) {
                    MessageBox.error("Failed to approve Service Entry Sheet. Please try again.");
                }
            });
        },

        onReject: function () {
            var oDialog = this.byId("rejectionDialog");
            this.byId("rejectionText").setValue("");
            oDialog.open();
        },

        onSubmitRejection: function () {
            var oView = this.getView(),
                oModel = oView.getModel(),
                oRejectionModel = oView.getModel("rejectionModel"),
                sRejectionText = oRejectionModel.getProperty("/rejectionText");

            if (!sRejectionText || sRejectionText.trim() === "") {
                MessageBox.warning("Please enter a rejection reason.");
                return;
            }

            this._executeRejection(oModel, sRejectionText);
        },

        _executeRejection: function (oModel, sRejectionText) {
            var sSESNumber = this.sSESNumber,
                sReleaseCode = "";

            // Get the next reject code from the binding context
            var oContext = this.getView().getBindingContext();
            if (oContext) {
                var oData = oContext.getObject();
                sReleaseCode = oData.NextRejectCode || "";
            }

            if (!sReleaseCode) {
                MessageBox.error("No reject code available.");
                return;
            }

            oModel.callFunction("/rejectServiceEntrySheet", {
                method: "POST",
                urlParameters: {
                    SESNumber: sSESNumber,
                    ReleaseCode: sReleaseCode,
                    RejectionText: sRejectionText
                },
                success: function (oData, oResponse) {
                    if (oData && oData.ActionSuccessful) {
                        MessageBox.success("Service Entry Sheet rejected successfully!", {
                            onClose: function () {
                                this.oRouter.navTo("worklist");
                            }.bind(this)
                        });
                    } else {
                        MessageBox.error(oData.Message || "Rejection failed.");
                    }
                }.bind(this),
                error: function (oError) {
                    MessageBox.error("Failed to reject Service Entry Sheet. Please try again.");
                }
            });

            this.byId("rejectionDialog").close();
        },

        onCancelRejection: function () {
            this.byId("rejectionDialog").close();
        },

        formatValue: function (fValue, sCurrency) {
            if (fValue === null || fValue === undefined) {
                return "";
            }
            return fValue.toLocaleString() + " " + (sCurrency || "");
        },

        formatDate: function (oDate) {
            if (!oDate) {
                return "";
            }
            var oDateFormat = DateFormat.getDateInstance({
                pattern: "dd.MM.yyyy"
            });
            return oDateFormat.format(new Date(oDate));
        },

        onBack: function () {
            this.oRouter.navTo("worklist");
        }
    });
});
