sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/format/DateFormat"
], function (Controller, Filter, FilterOperator, DateFormat) {
    "use strict";

    return Controller.extend("com.sap.mm.sesapproval.controller.Worklist", {
        onInit: function () {
            this.oRouter = this.getOwnerComponent().getRouter();
            this.oRouter.getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);
        },

        _onObjectMatched: function () {
            // Refresh data when navigating to worklist
            var oList = this.byId("worklistTable");
            if (oList) {
                oList.getBinding("items").refresh();
            }
        },

        onSearch: function (oEvent) {
            var sQuery = oEvent.getParameter("query"),
                aFilters = [];

            if (sQuery) {
                aFilters.push(new Filter({
                    filters: [
                        new Filter("SESNumber", FilterOperator.Contains, sQuery),
                        new Filter("PONumber", FilterOperator.Contains, sQuery),
                        new Filter("ServiceProviderName", FilterOperator.Contains, sQuery)
                    ],
                    and: false
                }));
            }

            var oList = this.byId("worklistTable");
            oList.getBinding("items").filter(aFilters);
        },

        onItemPress: function (oEvent) {
            var oItem = oEvent.getSource(),
                oContext = oItem.getBindingContext(),
                sSESNumber = oContext.getProperty("SESNumber"),
                sPackageNumber = oContext.getProperty("PackageNumber");

            this.oRouter.navTo("object", {
                SESNumber: sSESNumber,
                PackageNumber: sPackageNumber
            });
        },

        formatValue: function (fValue, sCurrency) {
            if (fValue === null || fValue === undefined) {
                return "";
            }
            return fValue.toLocaleString() + " " + (sCurrency || "");
        },

        formatDate: function (oDate) {
            if (!oDate) {
                return "";
            }
            var oDateFormat = DateFormat.getDateInstance({
                pattern: "dd.MM.yyyy"
            });
            return oDateFormat.format(new Date(oDate));
        },

        getNextActionText: function (sNextReleaseCode, sNextRejectCode) {
            if (sNextReleaseCode) {
                return "Approve (" + sNextReleaseCode + ")";
            } else if (sNextRejectCode) {
                return "Reject (" + sNextRejectCode + ")";
            }
            return "No Action Available";
        }
    });
});
