sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
    "use strict";

    return Controller.extend("com.sap.mm.sesapproval.controller.App", {
        onInit: function () {
            // Initialize the app
        }
    });
});
