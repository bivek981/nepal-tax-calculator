# SES Approval Fiori Application

## Overview
This is a simple SAP Fiori application for approving/rejecting Service Entry Sheets (SES) using the MM_SES_APPROVE OData service.

## Application Structure
```
webapp/
├── Component.js              # Main UI5 component
├── manifest.json             # App descriptor (routing, models, data sources)
├── index.html                # Entry point
├── controller/
│   ├── App.controller.js     # Main app controller
│   ├── Worklist.controller.js # Worklist page logic
│   ├── Object.controller.js  # Detail page with approve/reject
│   └── NotFound.controller.js # Error page
├── view/
│   ├── App.view.xml          # Root view
│   ├── Worklist.view.xml     # List of pending approvals
│   ├── Object.view.xml       # Detail page with tabs
│   └── NotFound.view.xml     # Error view
├── model/
│   └── models.js             # Device model
├── i18n/
│   └── i18n.properties       # Text translations
└── css/
    └── style.css             # Custom styles
```

## Features
1. **Worklist View**: Shows all pending SES approvals with search functionality
2. **Detail Page**: Displays complete SES information with tabs for:
   - Header details
   - Line items
   - Account assignments
   - Attachments
   - Notes
3. **Approval Actions**: Approve/Reject buttons with confirmation dialogs

## Deployment Options

### Option 1: Deploy to SAP Gateway (BSP Application)

#### Step 1: Prepare the Application
1. Zip the entire `webapp` folder contents
2. Name it `sesapproval.zip`

#### Step 2: Create BSP Application in SAP Gateway
1. Log into your SAP Gateway system (SEGW or SE80)
2. Transaction **SE80** → Create BSP Application
   - Name: `ZSES_APPROVAL`
   - Description: "SES Approval App"
   - Package: `$TMP` or your custom package
3. Right-click on the BSP → Import → Files from Archive
4. Upload `sesapproval.zip`

#### Step 3: Configure ICF Node
1. Transaction **SICF**
2. Navigate to: `/sap/bc/bsp/sap/zses_approval`
3. Right-click → Activate Service
4. Note the URL: `https://<your-server>:<port>/sap/bc/bsp/sap/zses_approval/index.html`

#### Step 4: Update manifest.json
Change the data source URI if needed:
```json
"dataSources": {
  "mainService": {
    "uri": "/sap/opu/odata/sap/MM_SES_APPROVE/",
    ...
  }
}
```

### Option 2: Deploy via SAP Business Application Studio

1. Open Business Application Studio
2. Create new project from template → SAP Fiori Application
3. Copy all files from this project
4. Right-click → Deploy → Deploy to ABAP Repository
5. Enter your Gateway system credentials
6. Select target package

### Option 3: Local Testing

1. Install local web server:
   ```bash
   npm install -g @ui5/cli
   ```

2. Run the app:
   ```bash
   cd SESApprovalApp
   ui5 serve --open index.html
   ```

3. For backend connection, configure proxy in `ui5.yaml` or use CORS proxy

## Role Assignment in Frontend

### Method 1: Using PFCG Roles (Recommended)

#### Step 1: Create PFCG Role in SAP
1. Transaction **PFCG**
2. Create role: `Z_SES_APPROVER`
3. Add authorization objects:
   - `S_DEVELOP` (for BSP access)
   - `S_RFC` (for OData calls)
   - `S_SERVICE` (for ICF access)
4. Add menu:
   - Type: Transaction
   - Value: `/sap/bc/bsp/sap/zses_approval`
5. Generate profile and save

#### Step 2: Assign Role to Users
1. Transaction **SU01**
2. Enter user ID
3. Go to Roles tab
4. Add `Z_SES_APPROVER`
5. Save

### Method 2: Authorization in Controller (Frontend Logic)

Add authorization checks in `Object.controller.js`:

```javascript
onInit: function () {
    // Check user authorization
    var oUser = sap.ushell.Container.getService("UserInfo");
    var sUserRole = oUser.getId();
    
    // You can check specific roles via backend call
    this._checkAuthorization();
},

_checkAuthorization: function () {
    var oModel = this.getView().getModel();
    oModel.read("/BusinessCards", {
        filters: [new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sap.ushell.Container.getService("UserInfo").getId())],
        success: function (oData) {
            if (oData.results.length > 0) {
                // User exists - show approve/reject buttons
                this.getView().byId("approveBtn").setVisible(true);
                this.getView().byId("rejectBtn").setVisible(true);
            }
        }.bind(this)
    });
}
```

### Method 3: Backend Authorization (Most Secure)

The OData service itself should enforce authorization:

1. In SEGW, implement `AUTHORITY_CHECK` in your DPC class
2. Check user has approval role before allowing POST to function imports
3. Return 403 error if unauthorized

## Configuration for Your System

### Update manifest.json with your server:
```json
"dataSources": {
  "mainService": {
    "uri": "http://ktmhofioridev.snpl.com.np:8000/sap/opu/odata/sap/MM_SES_APPROVE/",
    ...
  }
}
```

**Note**: For production, use relative path `/sap/opu/odata/...` and configure destination in SICF.

## Testing the App

1. **Access the app**: Open the deployed URL in browser
2. **Login**: Use your SAP credentials
3. **View worklist**: See all pending SES approvals
4. **Search**: Filter by SES Number, PO Number, or Provider
5. **Click item**: Navigate to detail page
6. **Approve**: Click Approve button → Confirm
7. **Reject**: Click Reject button → Enter reason → Submit

## Troubleshooting

### CORS Issues
If you get CORS errors when testing locally:
1. Enable CORS in SAP Gateway (transaction /IWFND/CORS)
2. Or deploy to SAP server (recommended)

### Authorization Errors
- Ensure user has PFCG role assigned
- Check ICF service is activated
- Verify OData service permissions

### Data Not Loading
- Check OData service URL in manifest.json
- Verify service is active in /IWFND/MAINT_SERVICE
- Check browser console for errors

## Next Steps

1. Customize branding (logo, colors)
2. Add more filters to worklist
3. Implement attachment download
4. Add email notifications
5. Create admin dashboard
